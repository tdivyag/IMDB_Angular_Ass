import { Component } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Directive, ElementRef } from '@angular/core';

const url:string = 'https://imdb-api.com/en/API/Top250Movies/k_bog20t4a';


@Directive({ selector: 'img' })
export class ImgLazyDirective {
  constructor({ nativeElement }: ElementRef<HTMLImageElement>) {
    const supports = 'loading' in HTMLImageElement.prototype;

    if (supports) {
      nativeElement.setAttribute('loading', 'lazy');
    }
  }
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  {
  title = 'angularAss';
  list;
  poltdata;
  constructor(private http: HttpClient){

  }

  ngOnInit(){
    
    this.http.get(url).subscribe( (data:any)=>{
      console.log(data)
      this.list = data.items;
      let i;
      for(i=0;i<(this.list).length;i++){
        let poltid=(this.list[i]).id;
        console.log(poltid);
        const polt:string = 'https://imdb-api.com/en/API/Title/k_bog20t4a/'+ poltid;
        this.http.get(polt).subscribe( (data:any)=>{
          this.poltdata=data;
        })
      }

      
    })
   /* this.http.get(polt).subscribe( (data:any)=>{
      console.log(data)
      this.poltdata = data.items;
    })*/
  }
}